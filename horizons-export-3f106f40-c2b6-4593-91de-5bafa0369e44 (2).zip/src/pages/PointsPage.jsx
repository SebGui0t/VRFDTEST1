
import React from "react";
import { motion } from "framer-motion";
import { Star, TrendingUp, Gift, Crown, Users } from "lucide-react";

const POINTS_DATA = {
  total: 2400,
  rank: 12,
  percentile: 95,
  history: [
    { date: "Today", amount: 50, source: "Sean Myer" },
    { date: "Yesterday", amount: 100, source: "Emma Chen" },
    { date: "2 days ago", amount: 75, source: "Community" }
  ]
};

const LEADERBOARD = [
  {
    rank: 1,
    name: "Brandon Green",
    points: 2400,
    avatar: "https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/b52401e886db022fa293100441675711.png"
  },
  {
    rank: 2,
    name: "Sean Myer",
    points: 2250,
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"
  },
  {
    rank: 3,
    name: "Emma Chen",
    points: 2100,
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb"
  }
];

const PointsPage = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-1 md:grid-cols-2 gap-6"
      >
        {/* Points Overview */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
          <div className="flex items-center gap-4 mb-6">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center"
            >
              <Star className="w-8 h-8 text-white" fill="white" />
            </motion.div>
            <div>
              <h1 className="text-2xl font-medium text-white">{POINTS_DATA.total}</h1>
              <p className="text-white/60">Total Points</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/5 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Crown className="w-4 h-4 text-amber-500" />
                <span className="text-white/60">Rank</span>
              </div>
              <p className="text-xl text-white">#{POINTS_DATA.rank}</p>
            </div>
            <div className="bg-white/5 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-green-500" />
                <span className="text-white/60">Percentile</span>
              </div>
              <p className="text-xl text-white">Top {POINTS_DATA.percentile}%</p>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Gift className="w-5 h-5 text-white" />
            <h2 className="text-lg font-medium text-white">Recent Activity</h2>
          </div>
          <div className="space-y-4">
            {POINTS_DATA.history.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between"
              >
                <div>
                  <p className="text-white">{item.source}</p>
                  <span className="text-sm text-white/60">{item.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-white" fill="white" />
                  <span className="text-white">+{item.amount}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Leaderboard */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-2 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-6">
            <Users className="w-5 h-5 text-white" />
            <h2 className="text-lg font-medium text-white">Leaderboard</h2>
          </div>
          <div className="space-y-4">
            {LEADERBOARD.map((user, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between bg-white/5 rounded-xl p-4"
              >
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 flex items-center justify-center">
                    <span className="text-lg font-medium text-white">#{user.rank}</span>
                  </div>
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-10 h-10 rounded-full object-cover border border-white/20"
                  />
                  <span className="text-white">{user.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-white" fill="white" />
                  <span className="text-white">{user.points}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default PointsPage;
