
import React from "react";
import { motion } from "framer-motion";
import { 
  Camera, 
  Share2, 
  LayoutGrid, 
  Repeat2, 
  Star, 
  Bookmark, 
  Play,
  MapPin,
  Plus
} from "lucide-react";

const ProfilePage = () => {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Cover Image */}
      <div className="relative h-48 sm:h-64 w-full">
        <img  
          className="w-full h-full object-cover"
          alt="Profile cover image"
         src="https://images.unsplash.com/photo-1690247571593-27a988539414" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80" />
      </div>

      {/* Profile Section */}
      <div className="relative px-4 pb-6 -mt-20">
        <div className="flex flex-col items-center">
          {/* Profile Picture */}
          <div className="relative">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="w-32 h-32 rounded-full border-4 border-black overflow-hidden"
            >
              <img 
                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/e82c2eefc2f6e0a62802c0b87d43d98e.png"
                alt="Brandon Green"
                className="w-full h-full object-cover"
              />
            </motion.div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="absolute bottom-0 right-0 p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              <Camera className="w-4 h-4" />
            </motion.button>
          </div>

          {/* Name and Badge */}
          <div className="mt-4 text-center">
            <div className="flex items-center justify-center gap-2">
              <h1 className="text-2xl font-medium">Brandon Green</h1>
              <span className="text-xl">|</span>
              <span className="text-white/80">Maejor</span>
            </div>
            <div className="flex items-center justify-center gap-2 mt-1">
              <MapPin className="w-4 h-4 text-white/60" />
              <span className="text-white/60">Los angeles CA</span>
            </div>
          </div>

          {/* Bio */}
          <p className="mt-4 text-center text-white/80 max-w-lg">
            Multi-platinum producer & singer. Cancer survivor. Co-Founder of VRFD and founder of The Frequency School. Worked with Justin Bieber, Drake, Ciara.
          </p>

          {/* Stats */}
          <div className="flex items-center justify-center gap-8 mt-6">
            <div className="text-center">
              <div className="text-xl font-medium">1878</div>
              <div className="text-sm text-white/60">Post</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-medium">1M</div>
              <div className="text-sm text-white/60">Followers</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-medium">1083</div>
              <div className="text-sm text-white/60">Following</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-medium">8k</div>
              <div className="text-sm text-white/60">subscribers</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 mt-6">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="px-6 py-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              Edit profile
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              <Share2 className="w-5 h-5" />
            </motion.button>
          </div>
        </div>

        {/* Navigation Icons */}
        <div className="flex items-center justify-between mt-8 px-4 py-3 bg-white/5 backdrop-blur-xl rounded-full">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full hover:bg-white/10"
          >
            <LayoutGrid className="w-5 h-5" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full hover:bg-white/10"
          >
            <Repeat2 className="w-5 h-5" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full hover:bg-white/10"
          >
            <Star className="w-5 h-5" fill="white" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full hover:bg-white/10"
          >
            <Bookmark className="w-5 h-5" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full hover:bg-white/10"
          >
            <Play className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-3 gap-1 mt-6">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="aspect-square bg-white/5 rounded-lg overflow-hidden"
          >
            <img  
              className="w-full h-full object-cover"
              alt="Post 1"
             src="https://images.unsplash.com/photo-1684100096778-e42597276e5a" />
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="aspect-square bg-white/5 rounded-lg overflow-hidden"
          >
            <img  
              className="w-full h-full object-cover"
              alt="Post 2"
             src="https://images.unsplash.com/photo-1552321873-6c6796efeb2a" />
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="aspect-square bg-white/5 rounded-lg overflow-hidden"
          >
            <img  
              className="w-full h-full object-cover"
              alt="Post 3"
             src="https://images.unsplash.com/photo-1692355672105-c6ae3299993b" />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
