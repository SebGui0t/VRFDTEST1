
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, Star, MessageCircle, Heart, UserPlus, Gift, Filter } from "lucide-react";

const NOTIFICATIONS = [
  {
    id: 1,
    type: "like",
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      username: "sean.myer"
    },
    content: "liked your post",
    time: "2m ago",
    read: false
  },
  {
    id: 2,
    type: "comment",
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      username: "sean.myer"
    },
    content: "commented: \"This is incredible! 🔥\"",
    time: "5m ago",
    read: false
  },
  {
    id: 3,
    type: "follow",
    user: {
      name: "Emma Chen",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
      username: "emma.designs"
    },
    content: "started following you",
    time: "15m ago",
    read: true
  }
];

const FILTERS = ["All", "Unread", "Likes", "Comments", "Follows", "Points"];

const NotificationIcon = ({ type, className = "w-8 h-8" }) => {
  const iconProps = {
    className: `${className} text-white`,
    strokeWidth: 1.5
  };

  const bgColors = {
    like: "bg-pink-500/20",
    comment: "bg-blue-500/20",
    follow: "bg-green-500/20",
    points: "bg-purple-500/20"
  };

  return (
    <div className={`${bgColors[type]} p-2 rounded-xl`}>
      {type === "like" && <Heart {...iconProps} />}
      {type === "comment" && <MessageCircle {...iconProps} />}
      {type === "follow" && <UserPlus {...iconProps} />}
      {type === "points" && <Gift {...iconProps} />}
    </div>
  );
};

const NotificationsPage = () => {
  const [selectedFilter, setSelectedFilter] = useState("All");
  const [showFilters, setShowFilters] = useState(false);

  const filteredNotifications = NOTIFICATIONS.filter(notification => 
    selectedFilter === "All" || 
    (selectedFilter === "Unread" && !notification.read) ||
    notification.type === selectedFilter.toLowerCase()
  );

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-white" />
          <h1 className="text-lg font-medium text-white">Notifications</h1>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowFilters(!showFilters)}
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
        >
          <Filter className="w-4 h-4 text-white" />
        </motion.button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4"
          >
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {FILTERS.map((filter) => (
                <motion.button
                  key={filter}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg border text-sm transition-colors ${
                    selectedFilter === filter
                      ? "bg-white/10 border-white/20 text-white"
                      : "border-white/10 text-white/60 hover:text-white hover:border-white/20"
                  }`}
                >
                  {filter}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {filteredNotifications.map((notification) => (
          <motion.div
            key={notification.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-4 ${
              !notification.read ? "border-l-4 border-l-blue-500" : ""
            }`}
          >
            <div className="flex items-start gap-4">
              <NotificationIcon type={notification.type} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-medium">{notification.user.name}</span>
                  <span className="text-white/60">@{notification.user.username}</span>
                </div>
                <p className="text-white/80">{notification.content}</p>
                <span className="block mt-2 text-sm text-white/40">{notification.time}</span>
              </div>
              <motion.img
                whileHover={{ scale: 1.05 }}
                src={notification.user.avatar}
                alt={notification.user.name}
                className="w-10 h-10 rounded-full object-cover border border-white/20"
              />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default NotificationsPage;
