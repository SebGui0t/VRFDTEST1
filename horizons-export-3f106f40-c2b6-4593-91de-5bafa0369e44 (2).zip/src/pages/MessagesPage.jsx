
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Send, Phone, Video, Info, MoreVertical, Smile, Image as ImageIcon, Mic, Star, ArrowLeft } from "lucide-react";

const CONVERSATIONS = [
  {
    id: 1,
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      status: "online",
      lastSeen: "Active now"
    },
    messages: [
      {
        id: 1,
        text: "Hey Brandon! Saw your latest post, absolutely amazing work! 🔥",
        time: "10:30 AM",
        sender: "them"
      },
      {
        id: 2,
        text: "Thanks Sean! Really appreciate the feedback. Been experimenting with some new techniques.",
        time: "10:32 AM",
        sender: "me"
      },
      {
        id: 3,
        text: "Would love to collaborate on something similar. What do you think?",
        time: "10:33 AM",
        sender: "them"
      }
    ]
  },
  {
    id: 2,
    user: {
      name: "Emma Chen",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
      status: "offline",
      lastSeen: "Last seen 2h ago"
    },
    messages: [
      {
        id: 1,
        text: "The new design system looks fantastic!",
        time: "Yesterday",
        sender: "them"
      }
    ]
  }
];

const MessagesPage = () => {
  const [selectedChat, setSelectedChat] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [showMobileChat, setShowMobileChat] = useState(false);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const updatedChat = {
      ...selectedChat,
      messages: [
        ...selectedChat.messages,
        {
          id: selectedChat.messages.length + 1,
          text: newMessage,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sender: "me"
        }
      ]
    };

    setSelectedChat(updatedChat);
    setNewMessage("");
  };

  const handleChatSelect = (chat) => {
    setSelectedChat(chat);
    setShowMobileChat(true);
  };

  const handleBackToList = () => {
    setShowMobileChat(false);
  };

  return (
    <div className="h-[calc(100vh-80px)] flex bg-black">
      {/* Conversations List */}
      <AnimatePresence initial={false}>
        {(!showMobileChat || window.innerWidth >= 640) && (
          <motion.div
            initial={{ x: -320, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -320, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="w-full sm:w-80 border-r border-white/10 overflow-hidden flex flex-col bg-black"
          >
            <div className="p-4 border-b border-white/10">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/60" />
                <input
                  type="text"
                  placeholder="Search messages"
                  className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm text-white placeholder-white/60 focus:outline-none focus:border-white/20"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {CONVERSATIONS.map((chat) => (
                <motion.button
                  key={chat.id}
                  whileHover={{ backgroundColor: "rgba(255, 255, 255, 0.05)" }}
                  onClick={() => handleChatSelect(chat)}
                  className={`w-full p-4 flex items-center gap-3 border-b border-white/5 transition-colors ${
                    selectedChat?.id === chat.id ? "bg-white/10" : ""
                  }`}
                >
                  <div className="relative">
                    <img
                      src={chat.user.avatar}
                      alt={chat.user.name}
                      className="w-12 h-12 rounded-full object-cover border border-white/20"
                    />
                    <div
                      className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-black ${
                        chat.user.status === "online" ? "bg-green-500" : "bg-gray-500"
                      }`}
                    />
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <h3 className="text-white font-medium truncate">{chat.user.name}</h3>
                    <p className="text-sm text-white/60 truncate">
                      {chat.messages[chat.messages.length - 1].text}
                    </p>
                  </div>
                  <span className="text-xs text-white/40">
                    {chat.messages[chat.messages.length - 1].time}
                  </span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Area */}
      <AnimatePresence initial={false}>
        {((showMobileChat && selectedChat) || window.innerWidth >= 640) && (
          <motion.div
            initial={{ x: 320, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 320, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute sm:relative w-full sm:w-auto flex-1 flex flex-col bg-black"
          >
            {selectedChat && (
              <>
                <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black">
                  <div className="flex items-center gap-3">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={handleBackToList}
                      className="sm:hidden p-1 rounded-full hover:bg-white/10"
                    >
                      <ArrowLeft className="w-5 h-5 text-white" />
                    </motion.button>
                    <img
                      src={selectedChat.user.avatar}
                      alt={selectedChat.user.name}
                      className="w-10 h-10 rounded-full object-cover border border-white/20"
                    />
                    <div>
                      <h2 className="text-white font-medium">{selectedChat.user.name}</h2>
                      <p className="text-sm text-white/60">{selectedChat.user.lastSeen}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <Phone className="w-5 h-5 text-white" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="hidden sm:block p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <Video className="w-5 h-5 text-white" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="hidden sm:block p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <Info className="w-5 h-5 text-white" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <MoreVertical className="w-5 h-5 text-white" />
                    </motion.button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {selectedChat.messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-2xl px-4 py-2 ${
                          message.sender === "me"
                            ? "bg-white/10 text-white"
                            : "bg-white/5 text-white"
                        }`}
                      >
                        <p>{message.text}</p>
                        <span className="text-xs text-white/40 mt-1 block">{message.time}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="p-4 border-t border-white/10 bg-black">
                  <div className="flex items-center gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <Smile className="w-5 h-5 text-white" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <ImageIcon className="w-5 h-5 text-white" />
                    </motion.button>
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      placeholder="Type a message..."
                      className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-white placeholder-white/60 focus:outline-none focus:border-white/20"
                    />
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setIsRecording(!isRecording)}
                      className={`p-2 rounded-full transition-colors ${
                        isRecording ? "bg-red-500/50" : "hover:bg-white/10"
                      }`}
                    >
                      <Mic className="w-5 h-5 text-white" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleSendMessage}
                      className="p-2 rounded-full hover:bg-white/10 transition-colors"
                    >
                      <Send className="w-5 h-5 text-white" />
                    </motion.button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MessagesPage;
