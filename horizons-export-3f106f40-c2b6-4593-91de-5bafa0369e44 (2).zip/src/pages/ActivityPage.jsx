
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, UserPlus, Star, Gift, Clock, Filter } from "lucide-react";

const ACTIVITIES = [
  {
    id: 1,
    type: "like",
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      username: "sean.myer"
    },
    content: "liked your post",
    time: "2m ago",
    postImage: "https://images.unsplash.com/photo-1613018788060-ecd2cc5ed3e8"
  },
  {
    id: 2,
    type: "follow",
    user: {
      name: "Emma Chen",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
      username: "emma.designs"
    },
    content: "started following you",
    time: "5m ago"
  },
  {
    id: 3,
    type: "comment",
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      username: "sean.myer"
    },
    content: "commented: \"Amazing work! 🔥\"",
    time: "15m ago",
    postImage: "https://images.unsplash.com/photo-1613018788060-ecd2cc5ed3e8"
  },
  {
    id: 4,
    type: "gift",
    user: {
      name: "Emma Chen",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
      username: "emma.designs"
    },
    content: "sent you 50 points",
    time: "1h ago",
    points: 50
  },
  {
    id: 5,
    type: "rating",
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      username: "sean.myer"
    },
    content: "gave you a 5-star rating",
    time: "2h ago",
    rating: 5
  }
];

const FILTERS = ["All", "Likes", "Comments", "Follows", "Gifts", "Ratings"];

const ActivityIcon = ({ type, className = "" }) => {
  switch (type) {
    case "like":
      return <Heart className={`${className} text-pink-500`} />;
    case "comment":
      return <MessageCircle className={`${className} text-blue-500`} />;
    case "follow":
      return <UserPlus className={`${className} text-green-500`} />;
    case "gift":
      return <Gift className={`${className} text-purple-500`} />;
    case "rating":
      return <Star className={`${className} text-amber-500`} />;
    default:
      return null;
  }
};

const ActivityPage = () => {
  const [selectedFilter, setSelectedFilter] = useState("All");
  const [showFilters, setShowFilters] = useState(false);

  const filteredActivities = ACTIVITIES.filter(activity => 
    selectedFilter === "All" || 
    activity.type.charAt(0).toUpperCase() + activity.type.slice(1) === selectedFilter
  );

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-white" />
          <h1 className="text-lg font-medium text-white">Recent Activity</h1>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowFilters(!showFilters)}
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
        >
          <Filter className="w-4 h-4 text-white" />
        </motion.button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4"
          >
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {FILTERS.map((filter) => (
                <motion.button
                  key={filter}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg border text-sm transition-colors ${
                    selectedFilter === filter
                      ? "bg-white/10 border-white/20 text-white"
                      : "border-white/10 text-white/60 hover:text-white hover:border-white/20"
                  }`}
                >
                  {filter}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {filteredActivities.map((activity) => (
          <motion.div
            key={activity.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-4"
          >
            <div className="flex items-start gap-4">
              <motion.img
                whileHover={{ scale: 1.05 }}
                src={activity.user.avatar}
                alt={activity.user.name}
                className="w-10 h-10 rounded-full object-cover border border-white/20"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-medium">{activity.user.name}</span>
                  <span className="text-white/60">@{activity.user.username}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ActivityIcon type={activity.type} className="w-4 h-4" />
                  <p className="text-white/80">{activity.content}</p>
                </div>
                {activity.postImage && (
                  <motion.img
                    whileHover={{ scale: 1.02 }}
                    src={activity.postImage}
                    alt="Post"
                    className="mt-3 rounded-lg w-full max-w-[200px] object-cover"
                  />
                )}
                {activity.points && (
                  <div className="mt-2 inline-flex items-center gap-1 px-2 py-1 rounded-full bg-purple-500/20 text-purple-300 text-sm">
                    <Gift className="w-3 h-3" />
                    <span>{activity.points} points</span>
                  </div>
                )}
                {activity.rating && (
                  <div className="mt-2 flex items-center gap-1">
                    {[...Array(activity.rating)].map((_, i) => (
                      <Star key={i} className="w-3 h-3 text-amber-500 fill-amber-500" />
                    ))}
                  </div>
                )}
                <span className="block mt-2 text-sm text-white/40">{activity.time}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ActivityPage;
