
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search as SearchIcon, TrendingUp, Clock, X, Users, SlidersHorizontal, Star, Crown } from "lucide-react";

const TRENDING_SEARCHES = [
  "Digital Art",
  "Future Tech",
  "AI Generated",
  "Cyberpunk",
  "Minimal Design"
];

const BEST_CREATORS = [
  {
    id: 1,
    name: "Brandon Green",
    username: "brandon.green",
    avatar: "https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/b52401e886db022fa293100441675711.png",
    status: "Verified Creator",
    followers: "245K",
    rating: "4.9"
  },
  {
    id: 2,
    name: "Sean Myer",
    username: "sean.myer",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
    status: "New Connection",
    followers: "182K",
    rating: "4.8"
  },
  {
    id: 3,
    name: "Emma Chen",
    username: "emma.designs",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
    status: "Rising Star",
    followers: "156K",
    rating: "4.7"
  }
];

const SMART_FILTERS = [
  { name: "Most Recent", icon: Clock },
  { name: "Top Rated", icon: Star },
  { name: "Trending", icon: TrendingUp },
  { name: "Featured", icon: Crown }
];

const SearchPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [recentSearches, setRecentSearches] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [activeFilter, setActiveFilter] = useState("Most Recent");

  useEffect(() => {
    const savedSearches = localStorage.getItem("recentSearches");
    if (savedSearches) {
      setRecentSearches(JSON.parse(savedSearches));
    }
  }, []);

  const handleSearch = (query) => {
    if (!query.trim()) return;

    const newSearches = [
      query,
      ...recentSearches.filter(search => search !== query)
    ].slice(0, 5);

    setRecentSearches(newSearches);
    localStorage.setItem("recentSearches", JSON.stringify(newSearches));
    setSearchQuery(query);
    setShowSuggestions(false);
  };

  const clearRecentSearch = (searchToRemove) => {
    const newSearches = recentSearches.filter(search => search !== searchToRemove);
    setRecentSearches(newSearches);
    localStorage.setItem("recentSearches", JSON.stringify(newSearches));
  };

  const clearAllRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem("recentSearches");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="relative mb-8">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSuggestions(true);
            }}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Search posts, people, or tags"
            className="w-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-full py-3 pl-12 pr-4 text-white placeholder-white/60 outline-none focus:border-white/20 transition-colors"
          />
        </div>

        <AnimatePresence>
          {showSuggestions && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute w-full mt-2 bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden z-10"
            >
              {recentSearches.length > 0 && (
                <div className="p-4 border-b border-white/10">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-white" />
                      <h3 className="text-sm text-white">Recent Searches</h3>
                    </div>
                    <button
                      onClick={clearAllRecentSearches}
                      className="text-xs text-white/60 hover:text-white transition-colors"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="space-y-2">
                    {recentSearches.map((search, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center justify-between group"
                      >
                        <button
                          onClick={() => handleSearch(search)}
                          className="text-sm text-white/80 hover:text-white transition-colors"
                        >
                          {search}
                        </button>
                        <button
                          onClick={() => clearRecentSearch(search)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3 text-white/60 hover:text-white" />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-4 border-b border-white/10">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-white" />
                  <h3 className="text-sm text-white">Trending</h3>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {TRENDING_SEARCHES.map((search, index) => (
                    <motion.button
                      key={index}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => handleSearch(search)}
                      className="text-left text-sm text-white/80 hover:text-white transition-colors"
                    >
                      {search}
                    </motion.button>
                  ))}
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Users className="w-4 h-4 text-white" />
                  <h3 className="text-sm text-white">Suggested Users</h3>
                </div>
                <div className="space-y-3">
                  {BEST_CREATORS.slice(0, 2).map((user, index) => (
                    <motion.div
                      key={user.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-8 h-8 rounded-full object-cover border border-white/20"
                        />
                        <div>
                          <h4 className="text-sm text-white">{user.name}</h4>
                          <p className="text-xs text-white/60">@{user.username}</p>
                        </div>
                      </div>
                      <span className="text-xs text-white/60">{user.status}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <SlidersHorizontal className="w-5 h-5 text-white" />
          <h2 className="text-lg font-medium text-white">Smart Filters</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {SMART_FILTERS.map((filter, index) => {
            const Icon = filter.icon;
            return (
              <motion.button
                key={filter.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setActiveFilter(filter.name)}
                className={`flex items-center gap-2 p-3 rounded-xl border ${
                  activeFilter === filter.name
                    ? 'bg-white/10 border-white/20'
                    : 'border-white/10 hover:border-white/20'
                } transition-colors`}
              >
                <Icon className="w-4 h-4 text-white" />
                <span className="text-sm text-white">{filter.name}</span>
              </motion.button>
            );
          })}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-6">
          <Crown className="w-5 h-5 text-white" />
          <h2 className="text-lg font-medium text-white">Best Creators</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {BEST_CREATORS.map((creator, index) => (
            <motion.div
              key={creator.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-4"
            >
              <div className="flex items-center gap-4 mb-4">
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-white/20"
                />
                <div>
                  <h3 className="text-white font-medium">{creator.name}</h3>
                  <p className="text-white/60">@{creator.username}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Star className="w-3 h-3 text-white fill-white" />
                    <span className="text-sm text-white">{creator.rating}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-white/60 text-sm">{creator.followers} followers</div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 py-1.5 rounded-full bg-white/10 text-white text-sm hover:bg-white/20 transition-colors"
                >
                  Follow
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchPage;
