
import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navigation from "@/components/Navigation";
import TopNav from "@/components/TopNav";
import Post from "@/components/Post";
import Sidebar from "@/components/Sidebar";
import RightPanel from "@/components/RightPanel";
import SearchPage from "@/pages/SearchPage";
import ActivityPage from "@/pages/ActivityPage";
import MessagesPage from "@/pages/MessagesPage";
import PointsPage from "@/pages/PointsPage";
import ProfilePage from "@/pages/ProfilePage";
import PostCreator2 from "@/components/PostCreator2";
import SearchModule from "@/components/SearchModule";

const VIEW_TYPES = {
  LIST: "list",
  GRID: "grid",
  PINTEREST: "pinterest"
};

const examplePosts = [
  {
    type: "text",
    text: "Just testing out the new text-only post feature. This is a simple example of how text posts look in our futuristic interface. #Innovation #Future"
  },
  {
    type: "photo",
    url: "https://images.unsplash.com/photo-1613018788060-ecd2cc5ed3e8"
  },
  {
    type: "video",
    url: "https://storage.googleapis.com/vrfd-demo-content/demo-video.mp4"
  },
  {
    type: "audio",
    url: "https://storage.googleapis.com/vrfd-demo-content/demo-audio.mp3"
  }
];

function MainFeed({ viewType, setViewType }) {
  const getLayoutClasses = () => {
    switch (viewType) {
      case VIEW_TYPES.GRID:
        return 'grid grid-cols-1 sm:grid-cols-2 gap-4';
      case VIEW_TYPES.PINTEREST:
        return 'columns-1 sm:columns-2 gap-4 space-y-4';
      default:
        return 'space-y-4';
    }
  };

  return (
    <div className="flex-1 min-w-0 max-w-[580px] mx-auto px-4 sm:px-6">
      <div className="mt-6 mb-4">
        <PostCreator2 />
      </div>
      <div className="mb-4">
        <SearchModule />
      </div>
      <div className={`${getLayoutClasses()} ${viewType === VIEW_TYPES.LIST ? 'px-0' : 'px-4'}`}>
        {examplePosts.map((post, i) => (
          <Post 
            key={i} 
            index={i} 
            content={post} 
            viewType={viewType} 
            className={viewType === VIEW_TYPES.PINTEREST ? 'break-inside-avoid' : ''}
          />
        ))}
      </div>
    </div>
  );
}

function App() {
  const [viewType, setViewType] = useState(VIEW_TYPES.LIST);

  return (
    <Router>
      <div className="flex min-h-screen bg-black">
        <TopNav />
        <div className="w-full pt-16 pb-20">
          <div className="max-w-[1720px] mx-auto flex gap-6">
            <div className="hidden lg:block w-[280px] fixed left-0 top-16 bottom-0 overflow-y-auto p-6">
              <Sidebar />
            </div>
            <div className="lg:ml-[280px] lg:mr-[280px] w-full">
              <Routes>
                <Route 
                  path="/" 
                  element={<MainFeed viewType={viewType} setViewType={setViewType} />} 
                />
                <Route path="/messages" element={<MessagesPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/activity" element={<ActivityPage />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/points" element={<PointsPage />} />
              </Routes>
            </div>
            <div className="hidden lg:block w-[280px] fixed right-0 top-16 bottom-0 overflow-y-auto p-6">
              <RightPanel />
            </div>
          </div>
        </div>
        <Navigation />
      </div>
    </Router>
  );
}

export default App;
