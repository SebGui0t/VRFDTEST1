
import React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Star, ChevronDown, LogOut, User, Shield, Settings, Moon, Sun, Palette } from "lucide-react";
import { Link } from "react-router-dom";
import { useTheme, themes } from "@/contexts/ThemeContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const TopNav = () => {
  const { scrollY } = useScroll();
  const opacity = useTransform(scrollY, [0, 100], [1, 0]);
  const { theme, changeTheme } = useTheme();

  const themeIcons = {
    [themes.dark]: <Moon className="w-4 h-4" />,
    [themes.light]: <Sun className="w-4 h-4" />,
    [themes.terra1]: <Palette className="w-4 h-4 text-orange-500" />,
    [themes.terra2]: <Palette className="w-4 h-4 text-blue-500" />
  };

  const nextTheme = {
    [themes.dark]: themes.light,
    [themes.light]: themes.terra1,
    [themes.terra1]: themes.terra2,
    [themes.terra2]: themes.dark
  };

  return (
    <nav className="fixed top-0 left-0 right-0 h-16 z-50 bg-background/20 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto h-full flex items-center justify-between px-4">
        <motion.div 
          className="logo-container"
          style={{ opacity }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <img 
            src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/93131652e0879b1e2074ac43f1bd9f02.png"
            alt="VRFD Logo"
            className="logo-image"
          />
        </motion.div>

        <motion.div 
          className="flex items-center space-x-2 bg-background/40 backdrop-blur-xl px-2 py-1.5 rounded-full border border-border"
          whileHover={{ scale: 1.02 }}
          style={{
            boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)",
            backdropFilter: "blur(8px)",
          }}
        >
          <Link to="/points">
            <motion.div 
              className="flex items-center space-x-1.5 pr-2 border-r border-border"
              whileHover={{ scale: 1.05 }}
            >
              <Star className="w-3.5 h-3.5 text-foreground" fill="currentColor" />
              <span className="text-[10px] font-medium text-foreground">2.4K</span>
            </motion.div>
          </Link>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => changeTheme(nextTheme[theme])}
            className="flex items-center space-x-1.5 px-2 border-r border-border"
          >
            {themeIcons[theme]}
          </motion.button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <motion.div 
                className="flex items-center space-x-1.5 pl-2 cursor-pointer"
                whileHover={{ scale: 1.05 }}
              >
                <img 
                  src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/b52401e886db022fa293100441675711.png"
                  alt="Profile"
                  className="w-6 h-6 rounded-full border-2 border-border"
                />
                <ChevronDown className="w-3 h-3 text-foreground" />
              </motion.div>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-36">
              <DropdownMenuItem className="flex items-center space-x-2">
                <User className="w-3.5 h-3.5" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex items-center space-x-2">
                <Shield className="w-3.5 h-3.5" />
                <span>Security</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex items-center space-x-2">
                <Settings className="w-3.5 h-3.5" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="flex items-center space-x-2 text-red-400">
                <LogOut className="w-3.5 h-3.5" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </motion.div>
      </div>
    </nav>
  );
};

export default TopNav;
