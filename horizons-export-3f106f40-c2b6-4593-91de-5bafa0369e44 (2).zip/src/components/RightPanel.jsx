
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Users } from "lucide-react";

const suggestedUsers = [
  {
    name: "USER_086",
    status: "TRENDING",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2"
  },
  {
    name: "USER_129",
    status: "RISING",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330"
  },
  {
    name: "USER_254",
    status: "ACTIVE",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9"
  }
];

const RightPanel = () => {
  return (
    <div className="space-y-4">
      <div className="bg-white/5 backdrop-blur-xl rounded-xl p-4 border border-white/10">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-4 h-4 text-white" />
          <h3 className="font-medium text-white">Suggested Connections</h3>
        </div>
        <div className="space-y-4">
          {suggestedUsers.map((user, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="w-10 h-10 rounded-full overflow-hidden border-2 border-white/20"
                >
                  <img 
                    src={user.avatar} 
                    alt={user.name}
                    className="w-full h-full object-cover"
                  />
                </motion.div>
                <div>
                  <h4 className="text-white font-mono text-sm">{user.name}</h4>
                  <p className="text-white/60 text-xs">{user.status}</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                className="text-white/80 hover:text-white hover:bg-white/10"
              >
                Follow
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RightPanel;
