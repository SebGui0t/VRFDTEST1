
import React from "react";
import { motion } from "framer-motion";
import { Plus } from "lucide-react";

const STORIES = [
  {
    id: 1,
    user: {
      name: "Brandon Green",
      avatar: "https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/b52401e886db022fa293100441675711.png"
    },
    isCreate: true
  },
  {
    id: 2,
    user: {
      name: "Sean Myer",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"
    }
  },
  {
    id: 3,
    user: {
      name: "Emma Chen",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb"
    }
  }
];

const Stories = () => {
  return (
    <div className="mb-6 overflow-x-auto">
      <div className="flex gap-4 px-1">
        {STORIES.map((story) => (
          <motion.button
            key={story.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex flex-col items-center gap-2"
          >
            <div className="relative">
              <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-tr from-purple-500 via-pink-500 to-orange-500">
                <div className="w-full h-full rounded-full border-2 border-black overflow-hidden">
                  <img
                    src={story.user.avatar}
                    alt={story.user.name}
                    className="w-full h-full object-cover"
                  />
                  {story.isCreate && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Plus className="w-6 h-6 text-white" />
                    </div>
                  )}
                </div>
              </div>
            </div>
            <span className="text-xs text-white/60 truncate w-16 text-center">
              {story.isCreate ? "Create" : story.user.name}
            </span>
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default Stories;
