
import React from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "react-router-dom";
import { Home, Search, Heart, MessageSquare } from "lucide-react";

const navItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: Search, label: "Search", path: "/search" },
  { isProfile: true, path: "/profile" },
  { icon: Heart, label: "Activity", path: "/activity" },
  { icon: MessageSquare, label: "Messages", path: "/messages" }
];

const NavIcon = ({ icon: Icon, label, isProfile, path }) => {
  const location = useLocation();
  const isActive = location.pathname === path;

  if (isProfile) {
    return (
      <Link to={path}>
        <motion.div
          whileHover={{ scale: 1.1 }}
          className="nav-profile"
        >
          <motion.img 
            src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/53ede24097f31d35bef801abf1bdac41.png" 
            alt="Brandon Green" 
            className="profile-picture"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          />
        </motion.div>
      </Link>
    );
  }

  return (
    <Link to={path}>
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        className={`nav-icon-mobile ${isActive ? 'text-white' : 'text-white/60'}`}
      >
        <Icon size={24} strokeWidth={1.5} />
      </motion.button>
    </Link>
  );
};

const Navigation = () => {
  return (
    <nav className="bottom-nav">
      <div className="nav-container">
        <div className="nav-items">
          {navItems.map((item, index) => (
            <NavIcon key={index} {...item} />
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
