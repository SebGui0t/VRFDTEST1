
import React from "react";

const StatCard = ({ title, value }) => (
  <div className="brutalist-card">
    <h4 className="text-sm text-white/60 mb-2">{title}</h4>
    <div className="flex justify-between items-center">
      <span className="text-2xl font-mono">{value}</span>
      <div className="w-24">
        <div className="progress-bar">
          <div className="progress-bar-fill" style={{ width: '70%' }} />
        </div>
      </div>
    </div>
  </div>
);

export default StatCard;
