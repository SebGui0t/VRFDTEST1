
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const Sidebar = () => {
  return (
    <div className="hidden lg:block w-80 p-6 brutalist-panel">
      <div className="brutalist-card">
        <div className="flex items-center mb-6">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="w-14 h-14 mr-4 avatar-container"
          >
            <img 
              alt="Profile picture" 
              className="w-full h-full object-cover" 
              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/e82c2eefc2f6e0a62802c0b87d43d98e.png" 
            />
          </motion.div>
          <div>
            <h3 className="font-mono">Brandon Green</h3>
            <p className="text-sm text-white/60">Verified Creator</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
