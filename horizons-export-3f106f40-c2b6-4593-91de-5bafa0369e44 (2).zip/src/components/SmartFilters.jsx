
import React, { useState } from "react";
import { motion } from "framer-motion";
import * as Slider from "@radix-ui/react-slider";
import { cn } from "@/lib/utils";

const TIME_RANGES = {
  today: "Today",
  "10w": "10w"
};

const USER_FILTERS = [
  { id: "human", label: "Human" },
  { id: "ai", label: "AI" },
  { id: "friends", label: "Friends" },
  { id: "fof", label: "Friends of my Friends" },
  { id: "all", label: "All" },
  { id: "country", label: "Country" }
];

const CONTENT_TYPES = [
  { id: "all", label: "All" },
  { id: "random", label: "Random" },
  { id: "music", label: "Music" },
  { id: "books", label: "Books" },
  { id: "design", label: "Design" }
];

const SmartFilters = ({ onApply, onCancel }) => {
  const [timeRange, setTimeRange] = useState([50]);
  const [selectedUserFilter, setSelectedUserFilter] = useState("human");
  const [selectedContentTypes, setSelectedContentTypes] = useState(["all"]);

  const handleContentTypeToggle = (type) => {
    if (type === "all") {
      setSelectedContentTypes(["all"]);
    } else {
      const newTypes = selectedContentTypes.includes(type)
        ? selectedContentTypes.filter(t => t !== type)
        : [...selectedContentTypes.filter(t => t !== "all"), type];
      setSelectedContentTypes(newTypes.length ? newTypes : ["all"]);
    }
  };

  const handleApply = () => {
    onApply({
      timeRange: timeRange[0],
      userFilter: selectedUserFilter,
      contentTypes: selectedContentTypes
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-black/90 backdrop-blur-xl rounded-t-3xl p-6 space-y-8"
    >
      <div className="space-y-4">
        <h2 className="text-xl font-medium text-white">Timeline</h2>
        <div className="relative pt-6">
          <div className="flex justify-between text-sm text-white/60 mb-2">
            <span>{TIME_RANGES.today}</span>
            <span>{TIME_RANGES["10w"]}</span>
          </div>
          <Slider.Root
            className="relative flex items-center select-none touch-none w-full h-5"
            value={timeRange}
            onValueChange={setTimeRange}
            max={100}
            step={1}
          >
            <Slider.Track className="bg-white/10 relative grow rounded-full h-[3px]">
              <Slider.Range className="absolute bg-white rounded-full h-full" />
            </Slider.Track>
            <Slider.Thumb
              className="block w-5 h-5 bg-white rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-white/50"
              aria-label="Time range"
            />
          </Slider.Root>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-medium text-white">Show</h2>
        <div className="grid grid-cols-2 gap-3">
          {USER_FILTERS.map(filter => (
            <motion.button
              key={filter.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedUserFilter(filter.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-3 rounded-xl border text-left transition-colors",
                selectedUserFilter === filter.id
                  ? "border-white text-white bg-white/10"
                  : "border-white/10 text-white/60 hover:border-white/20"
              )}
            >
              <div className={cn(
                "w-4 h-4 rounded-full border-2",
                selectedUserFilter === filter.id
                  ? "border-white bg-white"
                  : "border-white/60"
              )} />
              <span>{filter.label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-medium text-white">Content Type</h2>
        <div className="flex flex-wrap gap-2">
          {CONTENT_TYPES.map(type => (
            <motion.button
              key={type.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleContentTypeToggle(type.id)}
              className={cn(
                "px-4 py-2 rounded-full border transition-colors",
                selectedContentTypes.includes(type.id)
                  ? "border-white text-white bg-white/10"
                  : "border-white/10 text-white/60 hover:border-white/20"
              )}
            >
              {type.label}
            </motion.button>
          ))}
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={onCancel}
          className="flex-1 py-3 rounded-full text-red-500 border border-white/10 hover:bg-white/5"
        >
          Cancel
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleApply}
          className="flex-1 py-3 rounded-full bg-white text-black hover:bg-white/90"
        >
          Apply
        </motion.button>
      </div>
    </motion.div>
  );
};

export default SmartFilters;
