
import React from "react";
import { motion } from "framer-motion";
import { Flame, Users, Search } from "lucide-react";

const FEED_TYPES = [
  { id: "curated", icon: Flame, label: "Curated" },
  { id: "following", icon: Users, label: "Following" },
  { id: "search", icon: Search, label: "Search" }
];

const FeedTabs = ({ activeFeed, onFeedChange }) => {
  return (
    <div className="flex items-center gap-2 mb-6">
      {FEED_TYPES.map((feed) => {
        const Icon = feed.icon;
        return (
          <motion.button
            key={feed.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onFeedChange(feed.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-colors ${
              activeFeed === feed.id
                ? "bg-white/10 border-white/20 text-white"
                : "border-white/10 text-white/60 hover:text-white hover:border-white/20"
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm">{feed.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
};

export default FeedTabs;
