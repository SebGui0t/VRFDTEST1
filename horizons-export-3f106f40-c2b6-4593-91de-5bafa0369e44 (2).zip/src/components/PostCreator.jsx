
import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Image, 
  Video, 
  Camera, 
  Mic, 
  Grid, 
  LayoutGrid, 
  SlidersHorizontal, 
  Sparkles,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const PostCreator = ({ onViewChange, currentView, viewTypes }) => {
  const { toast } = useToast();
  const [postText, setPostText] = useState("");
  const [isAlgorithmEnabled, setIsAlgorithmEnabled] = useState(true);
  const [selectedMedia, setSelectedMedia] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioStream, setAudioStream] = useState(null);
  const [videoStream, setVideoStream] = useState(null);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [recordedChunks, setRecordedChunks] = useState([]);
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const textareaRef = useRef(null);
  
  useEffect(() => {
    return () => {
      if (audioStream) {
        audioStream.getTracks().forEach(track => track.stop());
      }
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [audioStream, videoStream]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [postText]);

  const handleFileUpload = (event, type) => {
    const file = event.target.files[0];
    if (file) {
      if ((type === "photo" && !file.type.startsWith("image/")) ||
          (type === "video" && !file.type.startsWith("video/"))) {
        toast({
          title: "Invalid file type",
          description: `Please select a ${type} file.`,
          variant: "destructive"
        });
        return;
      }

      setSelectedMedia({
        type,
        file,
        preview: URL.createObjectURL(file)
      });
      toast({
        title: "File uploaded",
        description: `Your ${type} has been added to the post.`
      });
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true,
        audio: false
      });
      setVideoStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setSelectedMedia({
        type: "camera",
        stream
      });
      toast({
        title: "Camera activated",
        description: "You can now take a photo."
      });
    } catch (error) {
      toast({
        title: "Camera error",
        description: "Unable to access camera. Please check permissions.",
        variant: "destructive"
      });
    }
  };

  const stopCamera = () => {
    if (videoStream) {
      videoStream.getTracks().forEach(track => track.stop());
      setVideoStream(null);
    }
    setSelectedMedia(null);
  };

  const takePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      canvas.getContext('2d').drawImage(videoRef.current, 0, 0);
      canvas.toBlob((blob) => {
        setSelectedMedia({
          type: "photo",
          file: blob,
          preview: canvas.toDataURL('image/jpeg')
        });
        stopCamera();
        toast({
          title: "Photo captured",
          description: "Your photo has been added to the post."
        });
      }, 'image/jpeg');
    }
  };

  const startAudioRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setAudioStream(stream);
      const recorder = new MediaRecorder(stream);
      setMediaRecorder(recorder);
      
      const chunks = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setSelectedMedia({
          type: "audio",
          file: blob,
          preview: URL.createObjectURL(blob)
        });
        setRecordedChunks(chunks);
        toast({
          title: "Audio recorded",
          description: "Your audio has been added to the post."
        });
      };
      
      recorder.start();
      setIsRecording(true);
      toast({
        title: "Recording started",
        description: "Recording your audio..."
      });
    } catch (error) {
      toast({
        title: "Microphone error",
        description: "Unable to access microphone. Please check permissions.",
        variant: "destructive"
      });
    }
  };

  const stopAudioRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stop();
      audioStream.getTracks().forEach(track => track.stop());
      setAudioStream(null);
      setIsRecording(false);
    }
  };

  const handleMediaClick = async (type) => {
    if (type === "photo" || type === "video") {
      fileInputRef.current.accept = type === "photo" ? "image/*" : "video/*";
      fileInputRef.current?.click();
    } else if (type === "camera") {
      if (videoStream) {
        stopCamera();
      } else {
        await startCamera();
      }
    } else if (type === "audio") {
      if (isRecording) {
        stopAudioRecording();
      } else {
        await startAudioRecording();
      }
    }
  };

  const clearMedia = () => {
    if (videoStream) {
      stopCamera();
    }
    if (audioStream) {
      audioStream.getTracks().forEach(track => track.stop());
      setAudioStream(null);
    }
    setSelectedMedia(null);
    setIsRecording(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handlePost = () => {
    if (!postText.trim() && !selectedMedia) {
      toast({
        title: "Empty post",
        description: "Please add some text or media to your post.",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Post created",
      description: "Your post has been published successfully!"
    });

    setPostText("");
    clearMedia();
  };

  const toggleFilter = () => {
    toast({
      title: "Filters applied",
      description: "Your content filters have been updated."
    });
  };

  const cycleViewType = () => {
    const viewOrder = [viewTypes.LIST, viewTypes.GRID, viewTypes.PINTEREST];
    const currentIndex = viewOrder.indexOf(currentView);
    const nextIndex = (currentIndex + 1) % viewOrder.length;
    onViewChange(viewOrder[nextIndex]);
    
    toast({
      title: "View changed",
      description: `Switched to ${viewOrder[nextIndex].toLowerCase()} view.`
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden"
    >
      <div className="p-4">
        <textarea
          ref={textareaRef}
          placeholder="What's on your mind today?"
          value={postText}
          onChange={(e) => setPostText(e.target.value)}
          className="w-full bg-transparent border-none outline-none text-white placeholder-white/60 resize-none text-lg"
          style={{ minHeight: '60px' }}
        />
      </div>

      <AnimatePresence>
        {selectedMedia && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="relative px-4"
          >
            <motion.button
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              onClick={clearMedia}
              className="absolute top-2 right-6 p-1.5 bg-black/60 rounded-full hover:bg-black/80 transition-colors z-10"
            >
              <X className="w-4 h-4 text-white" />
            </motion.button>
            {selectedMedia.type === "photo" && (
              <img
                src={selectedMedia.preview}
                alt="Selected"
                className="w-full rounded-lg object-cover max-h-96"
              />
            )}
            {selectedMedia.type === "video" && (
              <video
                src={selectedMedia.preview}
                controls
                className="w-full rounded-lg max-h-96"
              />
            )}
            {selectedMedia.type === "camera" && (
              <div className="relative rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full max-h-96"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={takePhoto}
                  className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white text-black hover:bg-white/90 px-4 py-2 rounded-full font-medium"
                >
                  Take Photo
                </motion.button>
              </div>
            )}
            {selectedMedia.type === "audio" && (
              <div className="bg-white/5 rounded-lg p-4 mb-4">
                <audio
                  src={selectedMedia.preview}
                  controls
                  className="w-full"
                />
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="border-t border-white/10 p-4">
        <div className="flex items-center justify-between">
          <div className="flex space-x-1">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              onChange={(e) => handleFileUpload(e, fileInputRef.current.accept.includes("image") ? "photo" : "video")}
            />
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMediaClick("photo")}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              <Image className="w-5 h-5 text-white" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMediaClick("video")}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              <Video className="w-5 h-5 text-white" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMediaClick("camera")}
              className={`p-2 rounded-full hover:bg-white/10 transition-colors ${videoStream ? 'bg-white/20' : ''}`}
            >
              <Camera className="w-5 h-5 text-white" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMediaClick("audio")}
              className={`p-2 rounded-full hover:bg-white/10 transition-colors ${isRecording ? 'bg-red-500/50' : ''}`}
            >
              <Mic className="w-5 h-5 text-white" />
            </motion.button>
          </div>

          <div className="flex items-center space-x-1">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={cycleViewType}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              {currentView === viewTypes.LIST ? (
                <Grid className="w-5 h-5 text-white" />
              ) : currentView === viewTypes.GRID ? (
                <LayoutGrid className="w-5 h-5 text-white" />
              ) : (
                <Grid className="w-5 h-5 text-white rotate-45" />
              )}
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleFilter}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              <SlidersHorizontal className="w-5 h-5 text-white" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setIsAlgorithmEnabled(!isAlgorithmEnabled);
                toast({
                  title: "Algorithm toggled",
                  description: `Algorithm is now ${isAlgorithmEnabled ? 'disabled' : 'enabled'}.`
                });
              }}
              className={`p-2 rounded-full hover:bg-white/10 transition-colors ${
                isAlgorithmEnabled ? 'text-white' : 'text-white/50'
              }`}
            >
              <Sparkles className="w-5 h-5" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handlePost}
              className="ml-1 bg-white text-black hover:bg-white/90 px-4 py-1.5 rounded-full text-sm font-medium transition-colors"
            >
              Post
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PostCreator;
