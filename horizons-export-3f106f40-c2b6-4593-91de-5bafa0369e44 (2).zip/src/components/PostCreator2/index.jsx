
import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Image, Video, Mic, Music, FileEdit, BarChart2, MessageSquare, Calendar, X } from "lucide-react";

const CONTENT_TYPES = [
  { id: "photo", icon: Image },
  { id: "audio", icon: Mic },
  { id: "music", icon: Music },
  { id: "blog", icon: FileEdit },
  { id: "poll", icon: BarChart2 },
  { id: "thread", icon: MessageSquare },
  { id: "event", icon: Calendar }
];

const PostCreator2 = () => {
  const [postText, setPostText] = useState("");
  const [selectedType, setSelectedType] = useState(null);
  const [selectedMedia, setSelectedMedia] = useState(null);
  const [pollOptions, setPollOptions] = useState(["", ""]);
  const [eventDetails, setEventDetails] = useState({
    title: "",
    date: "",
    time: "",
    location: ""
  });
  const fileInputRef = useRef(null);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedMedia({
        type: selectedType,
        file,
        preview: URL.createObjectURL(file)
      });
    }
  };

  const handleMediaClick = (type) => {
    setSelectedType(type);
    if (type === "photo" || type === "audio" || type === "music") {
      fileInputRef.current.accept = type === "photo" ? "image/*" : "audio/*";
      fileInputRef.current?.click();
    }
  };

  const handlePollOptionChange = (index, value) => {
    const newOptions = [...pollOptions];
    newOptions[index] = value;
    setPollOptions(newOptions);
  };

  const addPollOption = () => {
    if (pollOptions.length < 4) {
      setPollOptions([...pollOptions, ""]);
    }
  };

  const clearContent = () => {
    setSelectedType(null);
    setSelectedMedia(null);
    setPollOptions(["", ""]);
    setEventDetails({
      title: "",
      date: "",
      time: "",
      location: ""
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const renderContentTypeInput = () => {
    switch (selectedType) {
      case "blog":
        return (
          <div className="space-y-3 px-4 pb-4">
            <img alt="Blog cover" className="w-full h-48 rounded-lg object-cover" src="https://images.unsplash.com/photo-1673528076919-a69be48560c6" />
            <textarea
              placeholder="Write your blog post..."
              className="w-full bg-transparent border border-border rounded-lg p-3 text-sm text-foreground placeholder-muted-foreground resize-none"
              rows={6}
            />
          </div>
        );

      case "poll":
        return (
          <div className="space-y-2 px-4 pb-4">
            {pollOptions.map((option, index) => (
              <input
                key={index}
                type="text"
                value={option}
                onChange={(e) => handlePollOptionChange(index, e.target.value)}
                placeholder={`Option ${index + 1}`}
                className="w-full bg-transparent border border-border rounded-lg p-2 text-sm text-foreground placeholder-muted-foreground"
              />
            ))}
            {pollOptions.length < 4 && (
              <button
                onClick={addPollOption}
                className="text-xs text-primary hover:text-primary/90"
              >
                + Add option
              </button>
            )}
          </div>
        );

      case "event":
        return (
          <div className="space-y-3 px-4 pb-4">
            <img alt="Event cover" className="w-full h-48 rounded-lg object-cover" src="https://images.unsplash.com/photo-1609541828483-c8c0b794a887" />
            <input
              type="text"
              placeholder="Event title"
              value={eventDetails.title}
              onChange={(e) => setEventDetails({ ...eventDetails, title: e.target.value })}
              className="w-full bg-transparent border border-border rounded-lg p-2 text-sm text-foreground placeholder-muted-foreground"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                value={eventDetails.date}
                onChange={(e) => setEventDetails({ ...eventDetails, date: e.target.value })}
                className="bg-transparent border border-border rounded-lg p-2 text-sm text-foreground"
              />
              <input
                type="time"
                value={eventDetails.time}
                onChange={(e) => setEventDetails({ ...eventDetails, time: e.target.value })}
                className="bg-transparent border border-border rounded-lg p-2 text-sm text-foreground"
              />
            </div>
            <input
              type="text"
              placeholder="Location"
              value={eventDetails.location}
              onChange={(e) => setEventDetails({ ...eventDetails, location: e.target.value })}
              className="w-full bg-transparent border border-border rounded-lg p-2 text-sm text-foreground placeholder-muted-foreground"
            />
          </div>
        );

      default:
        return selectedMedia && (
          <div className="px-4 pb-4">
            {selectedMedia.type === "photo" && (
              <img
                src={selectedMedia.preview}
                alt="Selected"
                className="w-full rounded-lg object-cover max-h-64"
              />
            )}
            {(selectedMedia.type === "audio" || selectedMedia.type === "music") && (
              <audio
                src={selectedMedia.preview}
                controls
                className="w-full"
              />
            )}
          </div>
        );
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-xl overflow-hidden"
    >
      <div className="p-4">
        <textarea
          value={postText}
          onChange={(e) => setPostText(e.target.value)}
          placeholder="What's on your mind?"
          className="w-full bg-transparent border-none outline-none text-foreground placeholder-muted-foreground resize-none text-sm"
          rows={3}
        />
      </div>

      <AnimatePresence>
        {selectedType && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="relative"
          >
            <motion.button
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              onClick={clearContent}
              className="absolute top-2 right-2 p-1.5 bg-background/80 backdrop-blur-sm rounded-full hover:bg-background/90 transition-colors z-10"
            >
              <X className="w-4 h-4 text-foreground" />
            </motion.button>
            {renderContentTypeInput()}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="border-t border-border p-3">
        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {CONTENT_TYPES.map((type) => {
              const Icon = type.icon;
              return (
                <motion.button
                  key={type.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleMediaClick(type.id)}
                  className={`p-2 rounded-lg transition-colors ${
                    selectedType === type.id 
                      ? "bg-primary/20 text-primary" 
                      : "hover:bg-accent text-foreground"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </motion.button>
              );
            })}
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="px-4 py-1.5 bg-primary text-primary-foreground rounded-full text-xs font-medium hover:bg-primary/90 transition-colors"
          >
            Post
          </motion.button>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>
    </motion.div>
  );
};

export default PostCreator2;
