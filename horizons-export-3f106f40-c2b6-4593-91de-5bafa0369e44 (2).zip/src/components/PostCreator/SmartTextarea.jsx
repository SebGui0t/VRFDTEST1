
import React, { useRef, useEffect } from "react";

const SmartTextarea = ({ value, onChange, placeholder, className }) => {
  const textareaRef = useRef(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${Math.min(Math.max(60, scrollHeight), 200)}px`;
    }
  }, [value]);

  return (
    <textarea
      ref={textareaRef}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`w-full bg-transparent border-none outline-none text-white placeholder-white/60 resize-none text-base leading-relaxed ${className}`}
      style={{
        minHeight: "60px",
        maxHeight: "200px"
      }}
    />
  );
};

export default SmartTextarea;
