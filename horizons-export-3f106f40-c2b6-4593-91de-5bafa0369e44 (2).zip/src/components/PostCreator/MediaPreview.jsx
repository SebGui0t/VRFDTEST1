
import React from "react";
import { motion } from "framer-motion";
import { X } from "lucide-react";

const MediaPreview = ({ selectedMedia, clearMedia, videoRef, takePhoto }) => {
  if (!selectedMedia) return null;

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      className="relative px-2 sm:px-4"
    >
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0 }}
        onClick={clearMedia}
        className="absolute top-2 right-2 sm:right-6 p-1.5 bg-black/60 rounded-full hover:bg-black/80 transition-colors z-10"
      >
        <X className="w-4 h-4 text-white" />
      </motion.button>

      {selectedMedia.type === "photo" && (
        <img
          src={selectedMedia.preview}
          alt="Selected"
          className="w-full rounded-lg object-cover max-h-72 sm:max-h-96"
        />
      )}

      {selectedMedia.type === "video" && (
        <video
          src={selectedMedia.preview}
          controls
          className="w-full rounded-lg max-h-72 sm:max-h-96"
        />
      )}

      {selectedMedia.type === "camera" && (
        <div className="relative rounded-lg overflow-hidden">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full max-h-72 sm:max-h-96"
          />
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={takePhoto}
            className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white text-black hover:bg-white/90 px-4 py-2 rounded-full text-sm font-medium"
          >
            Take Photo
          </motion.button>
        </div>
      )}

      {selectedMedia.type === "audio" && (
        <div className="bg-white/5 rounded-lg p-3 sm:p-4 mb-2 sm:mb-4">
          <audio
            src={selectedMedia.preview}
            controls
            className="w-full"
          />
        </div>
      )}
    </motion.div>
  );
};

export default MediaPreview;
