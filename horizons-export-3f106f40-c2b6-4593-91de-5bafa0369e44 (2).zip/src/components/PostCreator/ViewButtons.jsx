
import React from "react";
import { motion } from "framer-motion";
import { Grid, LayoutGrid, SlidersHorizontal, Sparkles } from "lucide-react";

const ViewButtons = ({ 
  cycleViewType, 
  currentView, 
  viewTypes, 
  toggleFilter, 
  isAlgorithmEnabled, 
  setIsAlgorithmEnabled,
  toast 
}) => {
  const buttonVariants = {
    hover: { scale: 1.05 },
    tap: { scale: 0.95 }
  };

  return (
    <div className="flex gap-0.5">
      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={cycleViewType}
        className="p-1 rounded-md bg-white/5 hover:bg-white/10 transition-colors"
      >
        {currentView === viewTypes.LIST ? (
          <Grid className="w-3.5 h-3.5 text-white" />
        ) : currentView === viewTypes.GRID ? (
          <LayoutGrid className="w-3.5 h-3.5 text-white" />
        ) : (
          <Grid className="w-3.5 h-3.5 text-white rotate-45" />
        )}
      </motion.button>

      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={toggleFilter}
        className="p-1 rounded-md bg-white/5 hover:bg-white/10 transition-colors"
      >
        <SlidersHorizontal className="w-3.5 h-3.5 text-white" />
      </motion.button>

      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={() => {
          setIsAlgorithmEnabled(!isAlgorithmEnabled);
          toast({
            title: "Algorithm toggled",
            description: `Algorithm is now ${isAlgorithmEnabled ? 'disabled' : 'enabled'}.`
          });
        }}
        className={`p-1 rounded-md transition-colors ${
          isAlgorithmEnabled 
            ? 'bg-white/20 text-white' 
            : 'bg-white/5 hover:bg-white/10 text-white/50'
        }`}
      >
        <Sparkles className="w-3.5 h-3.5" />
      </motion.button>
    </div>
  );
};

export default ViewButtons;
