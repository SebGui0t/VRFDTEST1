
import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Image, Video, Mic } from "lucide-react";
import SmartTextarea from "./SmartTextarea";
import ContentTypeSelector from "./ContentTypeSelector";

const PostCreator = () => {
  const [contentType, setContentType] = useState("text");
  const [postText, setPostText] = useState("");
  const [selectedMedia, setSelectedMedia] = useState(null);
  const fileInputRef = useRef(null);

  const handleContentTypeSelect = (type) => {
    setContentType(type);
    setSelectedMedia(null);
  };

  const handleMediaClick = (type) => {
    if (type === "image" || type === "video") {
      fileInputRef.current.accept = type === "image" ? "image/*" : "video/*";
      fileInputRef.current?.click();
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedMedia({
        type: file.type.startsWith("image/") ? "image" : "video",
        file,
        preview: URL.createObjectURL(file)
      });
    }
  };

  const clearMedia = () => {
    setSelectedMedia(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden"
    >
      <div className="p-4">
        <SmartTextarea
          value={postText}
          onChange={(e) => setPostText(e.target.value)}
          placeholder="What's on your mind?"
        />
      </div>

      <AnimatePresence>
        {selectedMedia && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="px-4 pb-4"
          >
            {selectedMedia.type === "image" && (
              <img
                src={selectedMedia.preview}
                alt="Selected"
                className="w-full rounded-lg object-cover max-h-96"
              />
            )}
            {selectedMedia.type === "video" && (
              <video
                src={selectedMedia.preview}
                controls
                className="w-full rounded-lg max-h-96"
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <ContentTypeSelector 
        selectedType={contentType}
        onSelect={handleContentTypeSelect}
      />

      <div className="border-t border-white/10 p-4">
        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMediaClick("image")}
              className="p-2 rounded-xl hover:bg-white/10 transition-colors"
            >
              <Image className="w-5 h-5 text-white" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMediaClick("video")}
              className="p-2 rounded-xl hover:bg-white/10 transition-colors"
            >
              <Video className="w-5 h-5 text-white" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-2 rounded-xl hover:bg-white/10 transition-colors"
            >
              <Mic className="w-5 h-5 text-white" />
            </motion.button>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="px-6 py-2 bg-white text-black rounded-full text-sm font-medium hover:bg-white/90 transition-colors"
          >
            Post
          </motion.button>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>
    </motion.div>
  );
};

export default PostCreator;
