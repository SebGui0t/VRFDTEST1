
import React from "react";
import { motion } from "framer-motion";
import { Image, Video, Camera, Mic } from "lucide-react";

const MediaButtons = ({ handleMediaClick, videoStream, isRecording }) => {
  const buttonVariants = {
    hover: { scale: 1.05 },
    tap: { scale: 0.95 }
  };

  return (
    <div className="flex gap-0.5">
      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={() => handleMediaClick("photo")}
        className="p-1 rounded-md bg-white/5 hover:bg-white/10 transition-colors"
      >
        <Image className="w-3.5 h-3.5 text-white" />
      </motion.button>

      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={() => handleMediaClick("video")}
        className="p-1 rounded-md bg-white/5 hover:bg-white/10 transition-colors"
      >
        <Video className="w-3.5 h-3.5 text-white" />
      </motion.button>

      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={() => handleMediaClick("camera")}
        className={`p-1 rounded-md transition-colors ${
          videoStream 
            ? 'bg-white/20' 
            : 'bg-white/5 hover:bg-white/10'
        }`}
      >
        <Camera className="w-3.5 h-3.5 text-white" />
      </motion.button>

      <motion.button
        variants={buttonVariants}
        whileHover="hover"
        whileTap="tap"
        onClick={() => handleMediaClick("audio")}
        className={`p-1 rounded-md transition-colors ${
          isRecording 
            ? 'bg-red-500/30' 
            : 'bg-white/5 hover:bg-white/10'
        }`}
      >
        <Mic className="w-3.5 h-3.5 text-white" />
      </motion.button>
    </div>
  );
};

export default MediaButtons;
