
import React from "react";
import { motion } from "framer-motion";
import { FileText, Image, Video, Mic, Music, FileEdit, BarChart2, MessageSquare as MessageSquareMore } from 'lucide-react';

const CONTENT_TYPES = [
  { id: "text", icon: FileText, label: "Text" },
  { id: "image", icon: Image, label: "Image" },
  { id: "video", icon: Video, label: "Video" },
  { id: "audio", icon: Mic, label: "Audio" },
  { id: "music", icon: Music, label: "Music" },
  { id: "blog", icon: FileEdit, label: "Blog" },
  { id: "poll", icon: BarChart2, label: "Poll" },
  { id: "thread", icon: MessageSquareMore, label: "Thread" }
];

const ContentTypeSelector = ({ selectedType, onSelect }) => {
  return (
    <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 p-4 border-t border-white/10">
      {CONTENT_TYPES.map((type) => {
        const Icon = type.icon;
        return (
          <motion.button
            key={type.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(type.id)}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-colors ${
              selectedType === type.id 
                ? "bg-white/20 text-white" 
                : "text-white/60 hover:text-white hover:bg-white/10"
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px]">{type.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
};

export default ContentTypeSelector;
