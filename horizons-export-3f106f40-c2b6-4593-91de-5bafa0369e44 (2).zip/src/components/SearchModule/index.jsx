
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Search, 
  Filter, 
  Calendar, 
  Users, 
  Hash, 
  Timer, 
  Globe, 
  CheckCircle, 
  Eye, 
  EyeOff,
  LayoutGrid, 
  Columns, 
  Smartphone,
  Sparkles,
  X,
  ChevronDown
} from "lucide-react";

const LIFESTYLE_CATEGORIES = [
  "Wellness", "Fashion", "Food", "Travel", "Tech", 
  "Music", "Art", "Relationships", "Business", 
  "Spirituality", "Fitness", "Education"
];

const POST_TYPES = [
  { id: "text", label: "Text" },
  { id: "image", label: "Image" },
  { id: "video", label: "Video" },
  { id: "audio", label: "Audio" },
  { id: "links", label: "Links" }
];

const SCROLL_TIMERS = [
  { value: 5, label: "5s" },
  { value: 15, label: "15s" },
  { value: 30, label: "30s" },
  { value: 60, label: "1m" }
];

const VIEW_MODES = [
  { id: "timeline", icon: Smartphone, label: "Timeline" },
  { id: "grid", icon: Columns, label: "Grid" },
  { id: "reels", icon: LayoutGrid, label: "Reels" }
];

const SearchModule = () => {
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPostTypes, setSelectedPostTypes] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [dateRange, setDateRange] = useState({ start: "", end: "" });
  const [scrollTimer, setScrollTimer] = useState(5);
  const [viewMode, setViewMode] = useState("timeline");
  const [isAIEnabled, setIsAIEnabled] = useState(true);
  const [showNSFW, setShowNSFW] = useState(true);
  const [showSponsored, setShowSponsored] = useState(true);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [radius, setRadius] = useState(50);
  const [language, setLanguage] = useState("en");
  const [contentLength, setContentLength] = useState("all");

  const handlePostTypeToggle = (type) => {
    setSelectedPostTypes(prev => 
      prev.includes(type)
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const handleCategoryToggle = (category) => {
    setSelectedCategories(prev => 
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  return (
    <div className="relative space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search posts, #tags, @users..."
          className="w-full bg-background/50 backdrop-blur-sm border border-border rounded-full pl-12 pr-4 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowFilters(!showFilters)}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 rounded-full hover:bg-accent"
        >
          <Filter className="w-4 h-4 text-foreground" />
        </motion.button>
      </div>

      {/* View Mode & AI Toggle */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {VIEW_MODES.map(mode => (
            <motion.button
              key={mode.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setViewMode(mode.id)}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === mode.id 
                  ? "bg-primary/20 text-primary" 
                  : "hover:bg-accent text-foreground"
              }`}
            >
              <mode.icon className="w-4 h-4" />
            </motion.button>
          ))}
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsAIEnabled(!isAIEnabled)}
          className={`p-1.5 rounded-lg transition-colors ${
            isAIEnabled 
              ? "bg-primary/20 text-primary" 
              : "hover:bg-accent text-foreground"
          }`}
        >
          <Sparkles className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Advanced Filters Panel */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="absolute top-full left-0 right-0 mt-2 bg-background/95 backdrop-blur-sm border border-border rounded-xl p-4 space-y-4 z-50"
          >
            {/* Post Types */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-foreground">Post Type</h3>
              <div className="flex flex-wrap gap-2">
                {POST_TYPES.map(type => (
                  <motion.button
                    key={type.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handlePostTypeToggle(type.id)}
                    className={`px-3 py-1 rounded-full text-xs transition-colors ${
                      selectedPostTypes.includes(type.id)
                        ? "bg-primary/20 text-primary border border-primary/20"
                        : "border border-border hover:border-primary/20"
                    }`}
                  >
                    {type.label}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Date Range */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-foreground">Date Range</h3>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="date"
                  value={dateRange.start}
                  onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                  className="bg-background border border-border rounded-lg p-2 text-sm"
                />
                <input
                  type="date"
                  value={dateRange.end}
                  onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                  className="bg-background border border-border rounded-lg p-2 text-sm"
                />
              </div>
            </div>

            {/* Categories */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-foreground">Categories</h3>
              <div className="flex flex-wrap gap-2">
                {LIFESTYLE_CATEGORIES.map(category => (
                  <motion.button
                    key={category}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleCategoryToggle(category)}
                    className={`px-3 py-1 rounded-full text-xs transition-colors ${
                      selectedCategories.includes(category)
                        ? "bg-primary/20 text-primary border border-primary/20"
                        : "border border-border hover:border-primary/20"
                    }`}
                  >
                    {category}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Scroll Timer */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-foreground">Scroll Timer</h3>
              <div className="flex items-center gap-2">
                {SCROLL_TIMERS.map(timer => (
                  <motion.button
                    key={timer.value}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setScrollTimer(timer.value)}
                    className={`px-3 py-1 rounded-full text-xs transition-colors ${
                      scrollTimer === timer.value
                        ? "bg-primary/20 text-primary border border-primary/20"
                        : "border border-border hover:border-primary/20"
                    }`}
                  >
                    {timer.label}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* More Options */}
            <div className="space-y-3 pt-2 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Language</span>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="bg-background border border-border rounded-lg px-2 py-1 text-sm"
                >
                  <option value="en">English</option>
                  <option value="es">Spanish</option>
                  <option value="fr">French</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Location Radius</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={radius}
                  onChange={(e) => setRadius(e.target.value)}
                  className="w-32"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Verified Only</span>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setVerifiedOnly(!verifiedOnly)}
                  className={`p-1.5 rounded-lg transition-colors ${
                    verifiedOnly ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                </motion.button>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Show NSFW</span>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowNSFW(!showNSFW)}
                  className="p-1.5 rounded-lg transition-colors"
                >
                  {showNSFW ? (
                    <Eye className="w-4 h-4 text-primary" />
                  ) : (
                    <EyeOff className="w-4 h-4 text-muted-foreground" />
                  )}
                </motion.button>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Show Sponsored</span>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowSponsored(!showSponsored)}
                  className="p-1.5 rounded-lg transition-colors"
                >
                  {showSponsored ? (
                    <Eye className="w-4 h-4 text-primary" />
                  ) : (
                    <EyeOff className="w-4 h-4 text-muted-foreground" />
                  )}
                </motion.button>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Content Length</span>
                <select
                  value={contentLength}
                  onChange={(e) => setContentLength(e.target.value)}
                  className="bg-background border border-border rounded-lg px-2 py-1 text-sm"
                >
                  <option value="all">All</option>
                  <option value="short">Short</option>
                  <option value="long">Long</option>
                </select>
              </div>
            </div>

            {/* Close Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowFilters(false)}
              className="absolute top-2 right-2 p-1.5 rounded-full hover:bg-accent"
            >
              <X className="w-4 h-4 text-foreground" />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchModule;
