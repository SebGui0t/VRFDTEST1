
import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, Rocket, Bookmark, MoreHorizontal, Play, Pause, Volume2, VolumeX, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";

const REACTIONS = [
  { emoji: "❤️", label: "love" },
  { emoji: "🤩", label: "star" },
  { emoji: "🔥", label: "fire" },
  { emoji: "😂", label: "laugh" },
  { emoji: "😤", label: "angry" },
  { emoji: "🤔", label: "thinking" },
  { emoji: "💅", label: "slay" }
];

const GIFT_POINTS = [
  { amount: 5, color: "bg-blue-500" },
  { amount: 10, color: "bg-purple-500" },
  { amount: 50, color: "bg-pink-500" },
  { amount: 100, color: "bg-amber-500" }
];

const Post = ({ index, content, viewType, className = "" }) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [showGiftPoints, setShowGiftPoints] = useState(false);
  const [selectedReaction, setSelectedReaction] = useState(null);
  const [selectedGiftPoint, setSelectedGiftPoint] = useState(null);
  const [longPressTimeout, setLongPressTimeout] = useState(null);
  const audioRef = useRef(null);
  const reactionRef = useRef(null);
  const giftRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (reactionRef.current && !reactionRef.current.contains(event.target)) {
        setShowReactions(false);
      }
      if (giftRef.current && !giftRef.current.contains(event.target)) {
        setShowGiftPoints(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleAudioPlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMuteToggle = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleLikeMouseDown = () => {
    const timeout = setTimeout(() => {
      setShowReactions(true);
    }, 500);
    setLongPressTimeout(timeout);
  };

  const handleLikeMouseUp = () => {
    if (longPressTimeout) {
      clearTimeout(longPressTimeout);
    }
  };

  const handleReactionSelect = (reaction) => {
    setSelectedReaction(reaction);
    setIsLiked(true);
    setShowReactions(false);
  };

  const handleGiftPointSelect = (point) => {
    setSelectedGiftPoint(point);
    setShowGiftPoints(false);
  };

  const handleLikeClick = () => {
    if (!showReactions) {
      if (!isLiked) {
        setSelectedReaction({ emoji: "❤️", label: "love" });
      } else {
        setSelectedReaction(null);
      }
      setIsLiked(!isLiked);
    }
  };

  const renderContent = () => {
    if (!content) {
      return (
        <div className={`mb-3 w-full ${viewType !== 'list' ? 'aspect-square' : ''}`}>
          <img 
            alt="Post content" 
            className="w-full h-full object-cover" 
            src="https://images.unsplash.com/photo-1613018788060-ecd2cc5ed3e8" 
          />
        </div>
      );
    }

    switch (content.type) {
      case "text":
        return (
          <div className="mb-3 px-3">
            <p className="text-white/90 text-sm">{content.text}</p>
          </div>
        );
      case "photo":
        return (
          <div className={`mb-3 w-full ${viewType !== 'list' ? 'aspect-square' : ''}`}>
            <img 
              alt="Photo post" 
              className="w-full h-full object-cover" 
              src={content.url} 
            />
          </div>
        );
      case "video":
        return (
          <div className={`mb-3 w-full ${viewType !== 'list' ? 'aspect-video' : ''}`}>
            <video 
              className="w-full h-full object-cover rounded-lg"
              controls
              src={content.url}
            />
          </div>
        );
      case "audio":
        return (
          <div className="mb-3 px-3">
            <div className="bg-white/5 rounded-lg p-3">
              <div className="flex items-center justify-between mb-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-white/10"
                  onClick={handleAudioPlayPause}
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <Play className="w-6 h-6" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-white/10"
                  onClick={handleMuteToggle}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <audio
                ref={audioRef}
                className="w-full"
                controls
                src={content.url}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: index * 0.1 }}
      className={`content-card ${viewType !== 'list' ? 'rounded-xl overflow-hidden' : 'sm:rounded-none sm:border-y border-white/10 sm:bg-transparent'} ${className}`}
    >
      <div className={`flex items-center justify-between ${viewType !== 'list' ? 'p-3' : 'mb-3 px-3'}`}>
        <div className="flex items-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="w-8 h-8 mr-2 avatar-container organic-hover"
          >
            <img 
              alt="Brandon Green" 
              className="w-full h-full object-cover" 
              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/b52401e886db022fa293100441675711.png" 
            />
          </motion.div>
          <div>
            <h3 className="font-medium text-white text-sm">Brandon Green</h3>
            <p className="text-xs text-white/60">Verified Creator</p>
          </div>
        </div>
        <Button variant="ghost" className="text-white/60 hover:text-white rounded-xl p-1">
          <MoreHorizontal size={16} />
        </Button>
      </div>

      {renderContent()}

      <div className={`flex justify-between items-center ${viewType !== 'list' ? 'p-3' : 'px-3 pb-3'}`}>
        <div className="flex items-center gap-3">
          <div className="relative" ref={reactionRef}>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onMouseDown={handleLikeMouseDown}
              onMouseUp={handleLikeMouseUp}
              onTouchStart={handleLikeMouseDown}
              onTouchEnd={handleLikeMouseUp}
              onClick={handleLikeClick}
              className="p-1.5 rounded-full hover:bg-white/10 transition-all"
            >
              {selectedReaction ? (
                <span className="text-base">{selectedReaction.emoji}</span>
              ) : (
                <Heart size={16} fill={isLiked ? "currentColor" : "none"} className="text-white" />
              )}
            </motion.button>

            <AnimatePresence>
              {showReactions && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 10 }}
                  className="absolute bottom-full left-0 mb-2 flex items-center gap-1 p-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/10"
                  style={{ boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)" }}
                >
                  {REACTIONS.map((reaction) => (
                    <motion.button
                      key={reaction.label}
                      whileHover={{ scale: 1.2 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleReactionSelect(reaction)}
                      className="text-base cursor-pointer transition-transform"
                    >
                      {reaction.emoji}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-1.5 rounded-full hover:bg-white/10 transition-all"
          >
            <MessageCircle size={16} className="text-white" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-1.5 rounded-full hover:bg-white/10 transition-all"
          >
            <Rocket size={16} className="text-white" />
          </motion.button>

          <div className="relative" ref={giftRef}>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowGiftPoints(!showGiftPoints)}
              className="p-1.5 rounded-full hover:bg-white/10 transition-all flex items-center gap-1"
            >
              <Gift size={16} className="text-white" />
              {selectedGiftPoint && (
                <span className="text-xs font-medium text-white">{selectedGiftPoint.amount}</span>
              )}
            </motion.button>

            <AnimatePresence>
              {showGiftPoints && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 10 }}
                  className="absolute bottom-full left-0 mb-2 flex items-center gap-1 p-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/10"
                  style={{ boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)" }}
                >
                  {GIFT_POINTS.map((point) => (
                    <motion.button
                      key={point.amount}
                      whileHover={{ scale: 1.2 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleGiftPointSelect(point)}
                      className={`${point.color} rounded-full w-6 h-6 flex items-center justify-center text-xs font-medium text-white shadow-lg`}
                    >
                      {point.amount}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsSaved(!isSaved)}
          className="p-1.5 rounded-full hover:bg-white/10 transition-all"
        >
          <Bookmark size={16} fill={isSaved ? "currentColor" : "none"} className="text-white" />
        </motion.button>
      </div>

      <div className={`${viewType !== 'list' ? 'px-3 pb-3' : 'px-3'}`}>
        <div className="flex items-center space-x-2 text-white/60 text-xs">
          <span>2.4K</span>
          <span>•</span>
          <span>142</span>
        </div>
      </div>
    </motion.div>
  );
};

export default Post;
