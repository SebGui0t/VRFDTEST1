
import React from "react";
import { Globe, Lock, DollarSign } from "lucide-react";

const VisibilityBadge = ({ visibility }) => {
  const badges = {
    public: {
      icon: Globe,
      text: "Public",
      className: "bg-green-500/20 text-green-400"
    },
    private: {
      icon: Lock,
      text: "Private",
      className: "bg-red-500/20 text-red-400"
    },
    paywalled: {
      icon: DollarSign,
      text: "Premium",
      className: "bg-purple-500/20 text-purple-400"
    }
  };

  const { icon: Icon, text, className } = badges[visibility];

  return (
    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] ${className}`}>
      <Icon className="w-3 h-3" />
      <span>{text}</span>
    </div>
  );
};

export default VisibilityBadge;
