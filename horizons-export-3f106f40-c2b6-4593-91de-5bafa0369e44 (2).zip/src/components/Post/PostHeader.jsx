
import React from "react";
import { motion } from "framer-motion";
import { MoreHorizontal, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const PostHeader = ({ user, isAIContent, toggleAIContent }) => {
  return (
    <div className="flex items-center justify-between p-3">
      <div className="flex items-center">
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="w-8 h-8 mr-2 avatar-container organic-hover"
        >
          <img 
            alt={user.name} 
            className="w-full h-full object-cover" 
            src={user.avatar} 
          />
        </motion.div>
        <div className="flex items-center gap-2">
          <div>
            <h3 className="font-medium text-white text-xs">{user.name}</h3>
            <p className="text-[10px] text-white/60">{user.status}</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleAIContent}
            className={`p-1 rounded-full transition-all ${
              isAIContent ? 'bg-blue-500/20 text-blue-400' : 'bg-green-500/20 text-green-400'
            }`}
          >
            {isAIContent ? (
              <Bot size={14} className="animate-pulse" />
            ) : (
              <User size={14} />
            )}
          </motion.button>
        </div>
      </div>
      <Button variant="ghost" className="text-white/60 hover:text-white rounded-xl p-1">
        <MoreHorizontal size={14} />
      </Button>
    </div>
  );
};

export default PostHeader;
