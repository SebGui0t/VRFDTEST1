
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, Rocket, Bookmark, Gift, Bot, User } from "lucide-react";

const REACTIONS = [
  { emoji: "❤️", label: "love" },
  { emoji: "🤩", label: "star" },
  { emoji: "🔥", label: "fire" },
  { emoji: "😂", label: "laugh" },
  { emoji: "😤", label: "angry" },
  { emoji: "🤔", label: "thinking" },
  { emoji: "💅", label: "slay" }
];

const GIFT_POINTS = [
  { amount: 5, color: "bg-blue-500" },
  { amount: 10, color: "bg-purple-500" },
  { amount: 50, color: "bg-pink-500" },
  { amount: 100, color: "bg-amber-500" }
];

const PostActions = ({
  isLiked,
  isSaved,
  showReactions,
  showGiftPoints,
  selectedReaction,
  selectedGiftPoint,
  handleLikeMouseDown,
  handleLikeMouseUp,
  handleLikeClick,
  handleReactionSelect,
  handleGiftPointSelect,
  setShowGiftPoints,
  setIsSaved,
  reactionRef,
  giftRef,
  isAIContent,
  toggleAIContent
}) => {
  return (
    <div className="flex justify-between items-center px-3 pb-3">
      <div className="flex items-center gap-2">
        <div className="relative" ref={reactionRef}>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onMouseDown={handleLikeMouseDown}
            onMouseUp={handleLikeMouseUp}
            onTouchStart={handleLikeMouseDown}
            onTouchEnd={handleLikeMouseUp}
            onClick={handleLikeClick}
            className="p-1 rounded-full hover:bg-white/10 transition-all"
          >
            {selectedReaction ? (
              <span className="text-sm">{selectedReaction.emoji}</span>
            ) : (
              <Heart size={14} fill={isLiked ? "currentColor" : "none"} className="text-white" />
            )}
          </motion.button>

          <AnimatePresence>
            {showReactions && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: 10 }}
                className="absolute bottom-full left-0 mb-2 flex items-center gap-1 p-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/10"
              >
                {REACTIONS.map((reaction) => (
                  <motion.button
                    key={reaction.label}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleReactionSelect(reaction)}
                    className="text-sm cursor-pointer transition-transform"
                  >
                    {reaction.emoji}
                  </motion.button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-1 rounded-full hover:bg-white/10 transition-all"
        >
          <MessageCircle size={14} className="text-white" />
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-1 rounded-full hover:bg-white/10 transition-all"
        >
          <Rocket size={14} className="text-white" />
        </motion.button>

        <div className="relative" ref={giftRef}>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowGiftPoints(!showGiftPoints)}
            className="p-1 rounded-full hover:bg-white/10 transition-all flex items-center gap-1"
          >
            <Gift size={14} className="text-white" />
            {selectedGiftPoint && (
              <span className="text-[10px] font-medium text-white">{selectedGiftPoint.amount}</span>
            )}
          </motion.button>

          <AnimatePresence>
            {showGiftPoints && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: 10 }}
                className="absolute bottom-full left-0 mb-2 flex items-center gap-1 p-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/10"
              >
                {GIFT_POINTS.map((point) => (
                  <motion.button
                    key={point.amount}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleGiftPointSelect(point)}
                    className={`${point.color} rounded-full w-5 h-5 flex items-center justify-center text-[10px] font-medium text-white shadow-lg`}
                  >
                    {point.amount}
                  </motion.button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleAIContent}
          className={`p-1 rounded-full transition-all ${
            isAIContent ? 'bg-blue-500/20 text-blue-400' : 'bg-green-500/20 text-green-400'
          }`}
        >
          {isAIContent ? (
            <Bot size={14} className="animate-pulse" />
          ) : (
            <User size={14} />
          )}
        </motion.button>
      </div>

      <div className="flex items-center gap-2">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsSaved(!isSaved)}
          className="p-1 rounded-full hover:bg-white/10 transition-all"
        >
          <Bookmark size={14} fill={isSaved ? "currentColor" : "none"} className="text-white" />
        </motion.button>
      </div>
    </div>
  );
};

export default PostActions;
