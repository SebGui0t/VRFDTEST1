
import React from "react";

const PostStats = ({ viewType }) => {
  return (
    <div className={`${viewType !== 'list' ? 'px-3 pb-3' : 'px-3'}`}>
      <div className="flex items-center space-x-2 text-white/60 text-[10px]">
        <span>2.4K</span>
        <span>•</span>
        <span>142</span>
      </div>
    </div>
  );
};

export default PostStats;
