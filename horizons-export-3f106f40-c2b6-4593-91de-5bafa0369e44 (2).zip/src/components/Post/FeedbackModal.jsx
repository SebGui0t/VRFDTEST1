
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

const FEEDBACK_OPTIONS = [
  "Offensive",
  "Low quality",
  "Spam",
  "Misinformation",
  "Not my taste"
];

const FeedbackModal = ({ isOpen, onClose, onSubmit }) => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [customFeedback, setCustomFeedback] = useState("");

  const handleSubmit = () => {
    onSubmit(selectedOption === "Other" ? customFeedback : selectedOption);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-card border border-border rounded-xl w-full max-w-md overflow-hidden"
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h3 className="text-lg font-medium text-white">Why did you rate this below 50%?</h3>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="p-1 rounded-full hover:bg-white/10"
              >
                <X className="w-5 h-5 text-white" />
              </motion.button>
            </div>

            <div className="p-4 space-y-2">
              {FEEDBACK_OPTIONS.map((option) => (
                <motion.button
                  key={option}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedOption(option)}
                  className={`w-full p-3 rounded-lg border text-left transition-colors ${
                    selectedOption === option
                      ? "bg-white/10 border-white/20 text-white"
                      : "border-white/10 text-white/60 hover:text-white hover:border-white/20"
                  }`}
                >
                  {option}
                </motion.button>
              ))}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedOption("Other")}
                className={`w-full p-3 rounded-lg border text-left transition-colors ${
                  selectedOption === "Other"
                    ? "bg-white/10 border-white/20 text-white"
                    : "border-white/10 text-white/60 hover:text-white hover:border-white/20"
                }`}
              >
                Other
              </motion.button>

              {selectedOption === "Other" && (
                <textarea
                  value={customFeedback}
                  onChange={(e) => setCustomFeedback(e.target.value)}
                  placeholder="Please provide your feedback..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-white placeholder-white/40 resize-none focus:outline-none focus:border-white/20"
                  rows={3}
                />
              )}

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setSelectedOption("Do not answer");
                  onClose();
                }}
                className="w-full p-3 rounded-lg border border-white/10 text-white/60 hover:text-white hover:border-white/20"
              >
                Do not answer
              </motion.button>
            </div>

            <div className="p-4 border-t border-border">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSubmit}
                disabled={!selectedOption || (selectedOption === "Other" && !customFeedback)}
                className="w-full py-2 rounded-full bg-white text-black font-medium hover:bg-white/90 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Submit Feedback
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FeedbackModal;
