
import React from "react";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

const PostContent = ({ content, viewType, audioRef, isPlaying, isMuted, handleAudioPlayPause, handleMuteToggle }) => {
  if (!content) {
    return (
      <div className={`mb-3 w-full ${viewType !== 'list' ? 'aspect-square' : ''}`}>
        <img 
          alt="Post content" 
          className="w-full h-full object-cover" 
          src="https://images.unsplash.com/photo-1613018788060-ecd2cc5ed3e8" 
        />
      </div>
    );
  }

  switch (content.type) {
    case "text":
      return (
        <div className="mb-3 px-3">
          <p className="text-white/90 text-xs">{content.text}</p>
        </div>
      );
    case "photo":
      return (
        <div className={`mb-3 w-full ${viewType !== 'list' ? 'aspect-square' : ''}`}>
          <img 
            alt="Photo post" 
            className="w-full h-full object-cover" 
            src={content.url} 
          />
        </div>
      );
    case "video":
      return (
        <div className={`mb-3 w-full ${viewType !== 'list' ? 'aspect-video' : ''}`}>
          <video 
            className="w-full h-full object-cover rounded-lg"
            controls
            src={content.url}
          />
        </div>
      );
    case "audio":
      return (
        <div className="mb-3 px-3">
          <div className="bg-white/5 rounded-lg p-3">
            <div className="flex items-center justify-between mb-3">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10"
                onClick={handleAudioPlayPause}
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10"
                onClick={handleMuteToggle}
              >
                {isMuted ? (
                  <VolumeX className="w-3 h-3" />
                ) : (
                  <Volume2 className="w-3 h-3" />
                )}
              </Button>
            </div>
            <audio
              ref={audioRef}
              className="w-full"
              controls
              src={content.url}
            />
          </div>
        </div>
      );
    default:
      return null;
  }
};

export default PostContent;
