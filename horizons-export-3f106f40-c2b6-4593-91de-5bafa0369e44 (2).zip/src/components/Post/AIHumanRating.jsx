
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, X } from "lucide-react";

const AIHumanRating = () => {
  const [showModal, setShowModal] = useState(false);
  const [rating, setRating] = useState(50);
  const [feedback, setFeedback] = useState("");

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setShowModal(true)}
        className="p-1.5 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-1.5"
      >
        <Eye className="w-4 h-4 text-white" />
        <span className="text-xs text-white/60">AI/Human</span>
      </motion.button>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-black/90 border border-white/10 rounded-xl w-full max-w-md overflow-hidden"
            >
              <div className="relative p-4 border-b border-white/10">
                <h3 className="text-lg font-medium text-white text-center">44% Not Sure</h3>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setShowModal(false)}
                  className="absolute right-4 top-4 p-1 rounded-full hover:bg-white/10"
                >
                  <X className="w-5 h-5 text-white" />
                </motion.button>
              </div>

              <div className="p-6 space-y-6">
                <div className="space-y-2">
                  <p className="text-sm text-white/60 text-center">Drag the slider from Human to AI.</p>
                  <div className="relative pt-6">
                    <div className="flex justify-between text-xs text-white/60 mb-2">
                      <span>(34) Human</span>
                      <span>(20) Not sure</span>
                      <span>AI (10)</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={rating}
                      onChange={(e) => setRating(e.target.value)}
                      className="w-full h-1 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-white/60">What made it feel real or artificial?</label>
                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Share your thoughts..."
                    className="w-full h-24 bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-white placeholder-white/40 resize-none focus:outline-none focus:border-white/20"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setShowModal(false)}
                    className="flex-1 py-2 rounded-lg border border-white/10 text-white hover:bg-white/5"
                  >
                    Skip
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      // Handle submission
                      setShowModal(false);
                    }}
                    className="flex-1 py-2 rounded-lg bg-white text-black font-medium hover:bg-white/90"
                  >
                    Submit
                  </motion.button>
                </div>
              </div>

              <div className="border-t border-white/10 p-4 space-y-4">
                <h4 className="text-white font-medium">Community Notes</h4>
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <img
                      src="https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/53ede24097f31d35bef801abf1bdac41.png"
                      alt="User"
                      className="w-10 h-10 rounded-full"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-white text-sm font-medium">Jose Portilla</h5>
                        <span className="text-xs text-white/40 px-2 py-0.5 rounded-full bg-white/10">Instructor</span>
                      </div>
                      <p className="text-white/60 text-xs">Head of Data Science, Pierian Data Inc.</p>
                      <p className="text-white/80 text-sm mt-2">Evidence suggests AI generation: smooth gradients, unrealistic lighting, and lack of natural imperfections.</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white font-medium">
                      AS
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-white text-sm font-medium">Anastasia Samantha</h5>
                        <span className="text-xs text-white/40">7 days ago</span>
                      </div>
                      <p className="text-white/80 text-sm mt-2">Metadata analysis indicates this image was produced using AI software.</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIHumanRating;
