
import React from "react";
import { motion } from "framer-motion";

const EMOJIS = ["😢", "😕", "😐", "🙂", "😊", "😃", "😄", "🤩", "🌟", "🔥"];

const GradientRating = ({ rating, onRate, isCreator, analytics }) => {
  return (
    <div className="px-3 pb-3">
      <div className="bg-white/5 rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-white/60">Rating</span>
          {rating && (
            <span className="text-sm text-white flex items-center gap-1">
              {EMOJIS[Math.floor(rating / 10) - 1]} {rating}/100
            </span>
          )}
        </div>
        
        <div className="relative h-2 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${rating || 0}%` }}
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
          />
          {!rating && (
            <div className="absolute inset-0 flex">
              {[...Array(10)].map((_, i) => (
                <motion.button
                  key={i}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onRate((i + 1) * 10)}
                  className="flex-1 h-full hover:bg-white/20 transition-colors"
                />
              ))}
            </div>
          )}
        </div>

        {isCreator && analytics && (
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/60">Total Ratings</span>
              <span className="text-white">{analytics.total}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/60">Average</span>
              <span className="text-white flex items-center gap-1">
                {EMOJIS[Math.floor(analytics.average / 10) - 1]} {analytics.average}/100
              </span>
            </div>
            {analytics.lowRatingFeedback && analytics.lowRatingFeedback.length > 0 && (
              <div className="mt-3">
                <span className="text-xs text-white/60">Feedback</span>
                <div className="mt-1 space-y-1">
                  {analytics.lowRatingFeedback.map((feedback, i) => (
                    <div key={i} className="text-xs text-white/80 bg-white/5 rounded-lg p-2">
                      {feedback}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default GradientRating;
