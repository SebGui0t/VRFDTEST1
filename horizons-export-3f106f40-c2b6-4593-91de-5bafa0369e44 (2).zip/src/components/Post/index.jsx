
import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import PostHeader from "./PostHeader";
import PostContent from "./PostContent";
import PostActions from "./PostActions";
import PostStats from "./PostStats";

const Post = ({ index, content, viewType, className = "" }) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [showGiftPoints, setShowGiftPoints] = useState(false);
  const [selectedReaction, setSelectedReaction] = useState(null);
  const [selectedGiftPoint, setSelectedGiftPoint] = useState(null);
  const [longPressTimeout, setLongPressTimeout] = useState(null);
  const [isAIContent, setIsAIContent] = useState(false);
  const audioRef = useRef(null);
  const reactionRef = useRef(null);
  const giftRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (reactionRef.current && !reactionRef.current.contains(event.target)) {
        setShowReactions(false);
      }
      if (giftRef.current && !giftRef.current.contains(event.target)) {
        setShowGiftPoints(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleAudioPlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMuteToggle = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleLikeMouseDown = () => {
    const timeout = setTimeout(() => {
      setShowReactions(true);
    }, 500);
    setLongPressTimeout(timeout);
  };

  const handleLikeMouseUp = () => {
    if (longPressTimeout) {
      clearTimeout(longPressTimeout);
    }
  };

  const handleReactionSelect = (reaction) => {
    setSelectedReaction(reaction);
    setIsLiked(true);
    setShowReactions(false);
  };

  const handleGiftPointSelect = (point) => {
    setSelectedGiftPoint(point);
    setShowGiftPoints(false);
  };

  const handleLikeClick = () => {
    if (!showReactions) {
      if (!isLiked) {
        setSelectedReaction({ emoji: "❤️", label: "love" });
      } else {
        setSelectedReaction(null);
      }
      setIsLiked(!isLiked);
    }
  };

  const toggleAIContent = () => {
    setIsAIContent(!isAIContent);
  };

  const user = {
    name: "Brandon Green",
    status: "Verified Creator",
    avatar: "https://storage.googleapis.com/hostinger-horizons-assets-prod/3f106f40-c2b6-4593-91de-5bafa0369e44/b52401e886db022fa293100441675711.png"
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: index * 0.1 }}
      className={`content-card ${viewType !== 'list' ? 'rounded-xl overflow-hidden' : 'sm:rounded-none sm:border-y border-white/10 sm:bg-transparent'} ${className}`}
    >
      <PostHeader user={user} isAIContent={isAIContent} toggleAIContent={toggleAIContent} />
      <PostContent
        content={content}
        viewType={viewType}
        audioRef={audioRef}
        isPlaying={isPlaying}
        isMuted={isMuted}
        handleAudioPlayPause={handleAudioPlayPause}
        handleMuteToggle={handleMuteToggle}
      />
      <PostActions
        isLiked={isLiked}
        isSaved={isSaved}
        showReactions={showReactions}
        showGiftPoints={showGiftPoints}
        selectedReaction={selectedReaction}
        selectedGiftPoint={selectedGiftPoint}
        handleLikeMouseDown={handleLikeMouseDown}
        handleLikeMouseUp={handleLikeMouseUp}
        handleLikeClick={handleLikeClick}
        handleReactionSelect={handleReactionSelect}
        handleGiftPointSelect={handleGiftPointSelect}
        setShowGiftPoints={setShowGiftPoints}
        setIsSaved={setIsSaved}
        reactionRef={reactionRef}
        giftRef={giftRef}
        isAIContent={isAIContent}
        toggleAIContent={toggleAIContent}
      />
      <PostStats viewType={viewType} />
    </motion.div>
  );
};

export default Post;
